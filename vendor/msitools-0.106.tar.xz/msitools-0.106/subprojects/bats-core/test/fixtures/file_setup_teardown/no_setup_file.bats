@test "test" {
    true
}