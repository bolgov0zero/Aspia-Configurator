@test "another test" {
    true
}