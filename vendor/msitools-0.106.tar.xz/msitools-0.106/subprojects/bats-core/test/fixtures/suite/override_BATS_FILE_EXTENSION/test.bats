@test "test.bats" {
    true
}
